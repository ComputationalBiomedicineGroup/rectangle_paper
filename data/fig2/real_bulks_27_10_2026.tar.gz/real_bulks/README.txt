Estimates and metrics of the eight omnideconv methods on real bulk RNA-seq datasets (main workflow)
autogenes, bayesprism, bisque, cibersortx, dwls, music, scaden, scdc; each with the normalisations of
the pipeline (pipeline/optimal_normalizations.csv).

HaoCleaned-sampled/   human PBMC reference (HaoCleaned downsampled to 14,744 cells)
  finotello, hoek     benchmark_results/results_main3, May 2025 (CIBERSORTx Sep 2025)
  morandini           benchmark_results/results_main_morandini_ncbi, Oct 2026 (corrected, full NCBI data)
  dietrich            benchmark_results/results_main3, Apr 2026; the metrics of CIBERSORTx were computed
                      afterwards (Oct 2026) from its estimates with pipeline/bin/computeMetricsNF.R;
                      its sample names, which CIBERSORTx returned changed by R's make.names
                      (95-CO350-EOT -> X95.CO350.EOT), were mapped back to those of the bulk first
tabula-muris/         mouse reference
  petitprez, chen     benchmark_results/results_mouse, Mar 2024

Folders: <method>_<reference>_<sc norm>_<bulk>_<bulk norm>_ct0_rep0/
  deconvolution.rds    estimated cell-type fractions (samples x cell types)
  results_metric.rds   correlation and RMSE per cell type and per sample, ground truth, estimates, runtimes
